import socket
import threading

class ChatServer:
    def __init__(self):
        self.host = '127.0.0.1'  # Cambia esto a la dirección del servidor
        self.port = 5555
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.clients = []

    def start_server(self):
        try:
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen()

            print(f'Servidor escuchando en {self.host}:{self.port}')

            while True:
                client_socket, addr = self.server_socket.accept()
                threading.Thread(target=self.handle_client, args=(client_socket,)).start()

        except Exception as e:
            print(f"Error: {e}")

    def handle_client(self, client_socket):
        nickname = client_socket.recv(1024).decode('utf-8')

        print(f'{nickname} se ha conectado desde {client_socket.getpeername()}')

        # Avisar a todos los clientes sobre la conexión
        message = f'{nickname} se ha conectado desde {client_socket.getpeername()}.'
        self.broadcast(message, client_socket)

        self.clients.append((client_socket, nickname))

        # Manejar los mensajes del cliente
        while True:
            try:
                message = client_socket.recv(1024).decode('utf-8')
                if not message:
                    break

                print(message)

                # Puedes agregar aquí la lógica del chat en el lado del servidor.

                # Por ahora, solo enviaremos el mensaje a todos los clientes
                self.broadcast(message, client_socket)

            except Exception as e:
                print(f"Error: {e}")
                break

        # Desconexión del cliente
        print(f'{nickname} se ha desconectado desde {client_socket.getpeername()}')

        # Avisar a todos los clientes sobre la desconexión
        message = f'{nickname} se ha desconectado.'
        self.broadcast(message, client_socket)

        # Eliminar cliente de la lista
        self.clients.remove((client_socket, nickname))
        client_socket.close()

    def broadcast(self, message, sender_socket):
        for client_socket, _ in self.clients:
            if client_socket != sender_socket:
                try:
                    client_socket.send(message.encode('utf-8'))
                except Exception as e:
                    print(f"Error: {e}")

if __name__ == "__main__":
    chat_server = ChatServer()
    chat_server.start_server()
